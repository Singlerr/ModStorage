<?php
$dir = "./sounds/train/";
$json = './sounds.json';
$output = '{';

echo '파일 목록 가져오기'.PHP_EOL;
if (is_dir($dir)){
	if ($handle = opendir($dir)){
		while (($file = readdir($handle)) !== false){
			if(strpos($file, '.ogg') !== false) {
				echo '파일명: '. $file .PHP_EOL;
				$file = explode('.', $file);
				$output = $output.'"train.'.$file[0].'": { "category": "neutral", "sounds": ["train/'.$file[0].'"] },';
			}
			else{
				echo $file.': ogg파일이 아님'.PHP_EOL;
			}
			
		}
	closedir($handle);                              
	}
}
$output = substr($output , 0, -1);
$output = $output.'}';
echo $output;

$file = fopen($json, "w") or die("퉤!");
fwrite($file, $output);
fclose($file);

?>