function stationAlert(entity, dataMap, soundType){
	if(entity.getTrainStateData(10) != 1){
		var notch = entity.getNotch();
		//Type별 이름, 길이 설정
		var typeNameList = ["train.rtm_pck_stationAlert_type1"];
		var typeTermList = [6000];

		//역 진입
		if(dataMap.getInt("pck_stationAlert") == 1){
			dataMap.setInt("pck_stationAlert", 2, 0);//←정차중으로 변경
			//↓최초1회 실행
			if(pck_stationAlert_first != 1){
				if(notch > -1) soundPlay();
				pck_stationAlert_starttime = Date.now();
				pck_stationAlert_first = 1;
			}
		}
		
		if(dataMap.getInt("pck_stationAlert") == 2){
			
			//역 정차중
			var now = Date.now();
			var starttime = pck_stationAlert_starttime;
			if(notch > -1){//제동 안걸림
				if(now > typeTermList[soundType] + starttime){
					pck_stationAlert_first = 0;
					pck_stationAlert_starttime = now;//타이머 초기화
					soundPlay();
				}
			}

			//출입문 開
			if(entity.doorMoveL != 0 || entity.doorMoveR != 0){
				dataMap.setInt("pck_stationAlert", 0, 0);
			}
		}

		function soundPlay(){
			var path = new ResourceLocation("sound_pck2", typeNameList[soundType]);
			RTMCore.proxy.playSound(entity, path, 1, 1);
		}
	}
}
//pck_stationAlert 0: 정차완료  1: 역진입  2: 정차중

var pck_stationAlert_first;
var pck_stationAlert_starttime;