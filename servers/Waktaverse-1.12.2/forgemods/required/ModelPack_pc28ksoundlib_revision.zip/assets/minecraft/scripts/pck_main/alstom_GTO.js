function allmute(){
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor0');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor1');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor2');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor3');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor4');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor5');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor6');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor7');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor8');
	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor9');
}

su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_loop', 1.0, 1.0);

//역행
if(notch > 0){
	if(speed > 0 && speed <= 3){
		var mvol8 = 0;
		if(speed <= 1.8){
			mvol8 = 0.87;
		}else if(speed <= 2.8){
			mvol8 = linener(speed, 1.8, 0.87, 2.8, 0.15);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor8', mvol8, 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor8');	}
	
	if(speed > 0.6 && speed <= 8.6){
		var mvol0 = 0;
		if(speed <= 1.6){
			mvol0 = linener(speed, 0.6, 0.12, 1.6, 0.5);
		}else if(speed <= 8.6){
			mvol0 = linener(speed, 1.6, 0.5, 8.6, 0.54);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor0', mvol0, 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor0');	}
	
	if(speed > 7.8 && speed <= 16){
		var mpit1 = 0;
		mpit1 = linener(speed, 7.8, 1, 16, 2);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor1', 0.5, mpit1);
	}else{ 	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor1');	}
	
	if(speed > 15.8 && speed <= 22.2){
		var mpit2 = 0;
		mpit2 = linener(speed, 15.8, 1, 22.2, 1.35);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor2', 0.5, mpit2);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor2');	}
	
	if(speed > 21.4 && speed <= 30){
		var mpit3 = 0;
		mpit3 = linener(speed, 21.4, 1, 30, 1.55);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor3', 0.5, mpit3);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor3');	}
	
	if(speed > 29.6 && speed <= 39.2){
		var mpit5 = 0;
		mpit5 = linener(speed, 29.6, 1, 39.2, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor5', 0.5, mpit5);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor5');	}
	
	/*if(speed > 30 && speed <= 30.2){
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor4', 2.6, 0.66);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor4');	}*/
	
	if(speed > 38.8){
		var mpit6 =0;
		var mvol6 = 0;
		mpit6 = linener(speed, 38.8, 1.28, 95, 1.95);
		mvol6 = linener(speed, 38.8, 0.34, 95, 0.2);
		if(speed > 95){
			mvol6 = 0.2;
			mpit6 = 1.95;
		}
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor6', mvol6, mpit6);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor6');	}
	
}else if(notch < 0){
	if(speed >= 1 && speed <= 4){
		var mvol0 = 0;
		if(speed <= 1){
			mvol0 = linener(speed, 0, 0.11, 1, 0.50);
		}else if(speed <= 4){
			mvol0 = linener(speed, 1, 0.50, 4, 0.51);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor0', mvol0, 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor0');	}
	
	if(speed > 3.6 && speed <= 17){
		var mvol9 = 0;
		var mpit9 = 0;
		if(speed <= 7.6){
			mvol9 = linener(speed, 3.6, 0.3, 7.6, 0.42);
		}else if(speed <= 7.8){
			mvol9 = linener(speed, 7.6, 0.42, 7.8, 0.50);
		}else if(speed <= 17){
			mvol9 = 5;
		}
		mpit9 = linener(speed, 3.6, 0.48, 17, 1.35);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor9', mvol9, mpit9);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor9');	}
	
	if(speed > 15.8 && speed <= 21.8){
		var mpit2 = 0;
		mpit2 = linener(speed, 15.8, 0.88, 21.8, 1.27);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor2', 0.5, mpit2);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor2');	}
	
	if(speed > 21.6 && speed <= 29.8){
		var mpit3 = 0;
		mpit3 = linener(speed, 21.6, 1, 29.8, 1.55);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor3', 0.5, mpit3);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor3');	}
	
	if(speed > 29.6 && speed <= 39.2){
		var mpit5 = 0;
		mpit5 = linener(speed, 29.6, 1, 39.2, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor5', 0.5, mpit5);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor5');	}
	
	if(speed > 38.8){
		var mpit6 = 0;
		var mvol6 = 0;
		mpit6 = linener(speed, 38.8, 1.28, 95, 1.95);
		mvol6 = linener(speed, 38.8, 0.34, 95, 0.2);
		if(speed > 95){
			mvol6 = 0.2;
			mpit6 = 1.95;
		}
		su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor6', mvol6, mpit6);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_alstom_GTO_motor6');	}
}else{
	allmute();
	
}

if(speed == 0){
	allmute();
}

mvolr = linener(speed, 5, 0, 100, 1);
mpitr = linener(speed, 0, 0, 100, 1);
if(mvol < 0){
	mvol = 0;
}
if(su.inTunnel()){
	su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_run2', mvolr, mpitr);
}else{
	su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_run2', 0, 1);
}
su.playSound('sound_pck2', 'train.rtm_pck_alstom_GTO_run0', mvolr, mpitr);