function allmute(){
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor0');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor1');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor2');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor3');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor4');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor5');
	//su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor6');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor7');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor8');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor9');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor10');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor11');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor12');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor13');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor14');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor15');
}
	
su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_loop', 0.4, 1.0);
	
if(notch > 0){
	//역행
	if(speed > 0 && speed <= 6.4){
		if(speed <= 4.2){
			mvol = linener(speed, 0, 0.42, 5.2, 0.44);
		}else{
			mvol = linener(speed, 5.2, 0.44, 6.4, 0);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor0', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor0');	}
	
	//if(speed > 4.6 && speed <= 15.2){
	if(speed > 3 && speed <= 15.2){
		if(speed <= 4.2){
			mvol = linener(speed, 3, 0, 4.2, 0.44);
		}else if(speed <= 11.2){
			mvol = linener(speed, 4.2, 0.44, 11.2, 0.5);
		}else{
			mvol = linener(speed, 11.2, 0.5, 15.2, 0);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor1', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor1');	}
	
	if(speed > 9.8 && speed <= 23.2){
		if(speed <= 21.8){
			mvol = linener(speed, 9.8, 0.44, 21.8, 0.56);
		}else{
			mvol = linener(speed, 21.8, 0.56, 23.2, 0);
		}
		mpit = linener(speed, 9.8, 1, 23.6, 1.38);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor2', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor2');	}
	
	if(speed > 21.2 && speed <= 32){
		if(speed <= 29.8){
			mvol = linener(speed, 21.2, 0.48, 29.8, 0.6);
		}else{
			mvol = linener(speed, 29.8, 0.6, 32, 0);
		}
		mpit = linener(speed, 21.2, 1, 32.4, 1.35);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor3', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor3');	}
	
	if(speed > 30.6 && speed <= 42){
		if(speed <= 40.8){
			mvol = linener(speed, 30.6, 0.5, 40.8, 0.67);
		}else{
			mvol = linener(speed, 40.8, 0.67, 42, 0);
		}
		mpit = linener(speed, 30.6, 1.01, 42.2, 1.37);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor4', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor4');	}
	
	if(speed > 35.6 && speed <= 45.8){
		if(speed <= 44){
			mvol = linener(speed, 35.6, 0.55, 44, 0.72);
		}else{
			mvol = linener(speed, 44, 0.72, 45.8, 0);
		}
		mpit = linener(speed, 35.6, 1.0, 45.8, 1.29);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor5', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor5');	}
	
	if(speed > 44.4 && speed <= 81.4){
		if(speed <= 61){
			mvol = linener(speed, 44.4, 0.53, 61, 0.58);
		}else{
			mvol = linener(speed, 61, 0.58, 81.4, 0.42);
		}
		mpit = linener(speed, 44.4, 1.0, 81.4, 1.17);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor7', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor7');	}
	
	if(speed > 48.6){
		mvol = linener(speed, 48.6, 0, 120, 0.95);
		mpit = linener(speed, 48.6, 0.93, 120, 1.95);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor8', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor8');	}
	
}else if(notch < 0){
	//제동
	if(speed > 1 && speed <= 13){
		if(speed <= 3){
			mvol = linener(speed, 1, 0, 3, 0.69);
		}else if(speed <= 6){
			mvol = linener(speed, 3, 0.63, 6, 0.69);
		}else{
			mvol = linener(speed, 6, 0.69, 14, 0.67);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor15', (mvol*1.45), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor15'); }
	
	if(speed > 12 && speed <= 20){
		if(speed <= 13){
			mvol = linener(speed, 12, 0, 13, 0.62);
		}else{
			mvol = linener(speed, 13, 0.62, 20, 0.59);
		}
		mpit = linener(speed, 13, 0.8, 20, 1.1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor14', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor14'); }
	
	if(speed > 19 && speed <= 28.4){
		if(speed <= 20){
			mvol = linener(speed, 19, 0, 20, 0.6);
		}else{
			mvol = linener(speed, 20, 0.6, 28.4, 0.54);
		}
		mpit = linener(speed, 19, 1, 28.6, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor13', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor13'); }
	
	if(speed > 27.6 && speed <= 35.6){
		if(speed <= 30.4){
			mvol = linener(speed, 27.6, 0, 30.4, 0.7);
		}else{
			mvol = linener(speed, 30.4, 0.7, 35.6, 0.68);
		}
		mpit = linener(speed, 27.6, 0.9, 35.6, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor12', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor12'); }
	
	if(speed > 35 && speed <= 41.2){
		if(speed <= 36){
			mvol = linener(speed, 35, 0, 36, 0.68);
		}else{
			mvol = linener(speed, 36, 0.68, 41.2, 0.63);
		}
		mpit = linener(speed, 35, 0.89, 41.2, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor11', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor11'); }
	
	if(speed > 39.4 && speed <= 46){
		if(speed <= 41.6){
			mvol = linener(speed, 39.4, 0, 41.6, 0.8);
		}else{
			mvol = linener(speed, 41.6, 0.8, 46, 0.74);
		}
		mpit = linener(speed, 39.4, 0.83, 46, 1.01);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor10', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor10'); }
	
	if(speed > 45 && speed <= 54.8){
		if(speed <= 47){
			mvol = linener(speed, 45, 0, 47, 0.74);
		}else{
			mvol = linener(speed, 47, 0.74, 54.8, 0.69);
		}
		mpit = linener(speed, 39.4, 0.88, 46, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor9', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor9'); }
	
	if(speed > 48.8){
		mvol = linener(speed, 48.8, 0.84, 120, 1.04);
		mpit = linener(speed, 48.8, 0.93, 120, 2.34);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor8', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_IGBT_motor8');	}
	}else{
	//타행
	allmute();
}
	
if(speed == 0){
	allmute();
}

if(speed < 50){
	mvolr = linener(speed, 5, 0, 50, 1);
}else{
	mvolr = linener(speed, 50, 1, 100, 2);
}
mpitr = linener(speed, 0, 0, 100, 1.2);
if(mvol < 0){
	mvol = 0;
}
if(su.inTunnel()){
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', (mvolr*1.2), mpitr);
}else{
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', 0, 1);
}
su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run0', (mvolr*1.5), mpitr);
